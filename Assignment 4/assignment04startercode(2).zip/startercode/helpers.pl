:- module( helpers,
	 [ readGame/5
	 , printGame/4
	 ]
    ).

readGame(File,Positions,Chutes,Ladders,Board):-
    open(File,read,Input),
    read(Input,Positions),
    read(Input,Chutes),
    read(Input,Ladders),
    readBoard(Input,Board),
    close(Input).

readBoard(Input,[]):-
    at_end_of_stream(Input),
    !.
readBoard(Input,[Row|Rows]):-
    \+ at_end_of_stream(Input),
    read(Input,Row),
    readBoard(Input,Rows).

printGame(Positions,Chutes,Ladders,Board):-
    writeln(positions),
    writeln(Positions),
    writeln(chutes),
    writeln(Chutes),
    writeln(ladders),
    writeln(Ladders),
    writeln(board),
    printBoard(Board).

printBoard([]).
printBoard([Row|Rows]):-
    writeln(Row),
    printBoard(Rows).
